#define MY_DTU_PRO ((uint64_t)0x1234567801ULL)
#define MY_MI_WR    0x106112345670ULL
#define MY_SSID "mySSID"
#define MY_WIFIPW "myPW"
#define MY_BREITE  11.2866
#define MY_LAENGE  3.3416
